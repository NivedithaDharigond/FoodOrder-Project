import React from 'react'

export default function Footer() {
  return (
    <div>
        <>
            <footer>
                <p className='text-center'>
                    Food Delivery website -2024. All Rights reserved by Niveditha
                </p>

            </footer>
        </>
    </div>
  )
}
